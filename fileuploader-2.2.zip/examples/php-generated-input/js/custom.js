$(document).ready(function() {
	
	// enable fileupload plugin
	// all fileuploader options are comming from PHP in the input attributes
	$('input:file').fileuploader();
	
});